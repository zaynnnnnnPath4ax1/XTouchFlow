# TouchFlow

Ye plain source-code hai — koi zip block, executable, ya hidden file nahi hai.
Sab kuch ordinary text/code/image files hain jo GitHub par safely upload ho jaayenge.

## App icon (dp)

Real TouchFlow logo se sahi size ke launcher icons already bana ke daal diye hain:

- `app/src/main/res/mipmap-mdpi/ic_launcher.png` (48x48)
- `app/src/main/res/mipmap-hdpi/ic_launcher.png` (72x72)
- `app/src/main/res/mipmap-xhdpi/ic_launcher.png` (96x96)
- `app/src/main/res/mipmap-xxhdpi/ic_launcher.png` (144x144)
- `app/src/main/res/mipmap-xxxhdpi/ic_launcher.png` (192x192)
- har density ke round variant (`ic_launcher_round.png`) bhi saath mein hai.

Web side ke liye (`app/src/main/assets/`) icons: `touchflow-icon-32.png`,
`touchflow-icon-180.png`, `touchflow-icon-192.png`, `touchflow-icon-512.png` —
ye browser tab icon aur "Add to Home Screen" dp dono ke liye use hote hain.

## GitHub par upload karna

1. GitHub par ek naya empty repository banao (README/gitignore add mat karna, khali rakhna).
2. Is poore `TouchFlowApp` folder ka content us repo mein upload/push kar do
   (drag-and-drop se ya `git push` se) — folder structure waisa hi rakhna jaisa hai.
3. Push hote hi do GitHub Actions workflows automatically chalenge:

### 1) APK build (`.github/workflows/build.yml`)
- Repo ke **Actions** tab mein "Build TouchFlow APK" workflow dikhega.
- Har push par (ya "Run workflow" button se manually) ye debug APK bana dega.
- Finished run kholo → **Artifacts** section se `TouchFlow-debug-apk` download kar lo.

### 2) Web build (`.github/workflows/pages.yml`)
- Repo Settings → Pages mein jaake source ko "GitHub Actions" set karo (ek baar).
- Push hote hi ye `app/src/main/assets` (wahi HTML jo app ke andar chalta hai)
  ko ek live website ke roop mein publish kar dega — URL Actions run ke output
  mein aur Settings → Pages mein milega.

## Local (Android Studio) se APK banana

1. Android Studio mein **File → Open** → is `TouchFlowApp` folder ko choose karo.
2. Gradle sync hone do (sirf `google()` aur `mavenCentral()` se free/official
   AndroxX libraries download hongi — koi paid ya untrusted source nahi).
3. **Build → Build Bundle(s)/APK(s) → Build APK(s)**.
