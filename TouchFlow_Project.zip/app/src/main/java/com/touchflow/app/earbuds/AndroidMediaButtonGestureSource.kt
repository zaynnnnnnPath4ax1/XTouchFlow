package com.touchflow.app.earbuds

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import android.view.KeyEvent

/**
 * Real gesture source backed by Android's standard media-button KeyEvent
 * stream (MediaSessionCompat) — i.e. AVRCP media-button commands most
 * Bluetooth earbuds already send once their own firmware resolves a
 * tap/hold on the earbud itself. This uses only official AndroidX media
 * APIs; it does not touch raw Bluetooth GATT and does not attempt to pair
 * or authenticate with anything outside the normal OS Bluetooth flow.
 *
 * If a given pair of earbuds never sends these standard events (custom
 * gesture firmware with no AVRCP passthrough), this source simply never
 * calls back — it does not guess or simulate.
 */
class AndroidMediaButtonGestureSource : EarbudGestureSource {

    override val id: String = "android_media_button"
    override val displayName: String = "Standard Android media buttons (AVRCP)"

    private var mediaSession: MediaSessionCompat? = null
    private val handler = Handler(Looper.getMainLooper())
    private var listener: EarbudGestureListener? = null

    // Real single/double/triple-click + hold detection over genuine
    // hardware KeyEvents — same TAP_WINDOW/HOLD_THRESHOLD debounce
    // contract already used for on-screen touch in GestureEngine
    // (index.html), just fed by real key events instead of pointer events.
    private var tapCount = 0
    private var tapRunnable: Runnable? = null
    private var holdRunnable: Runnable? = null
    private var holdFired = false

    companion object {
        private const val TAP_WINDOW_MS = 320L
        private const val HOLD_THRESHOLD_MS = 500L
    }

    override fun start(context: Context, listener: EarbudGestureListener) {
        if (mediaSession != null) return // already running — idempotent
        this.listener = listener

        mediaSession = MediaSessionCompat(context, "TouchFlowMediaSession").apply {
            setFlags(
                MediaSessionCompat.FLAG_HANDLES_MEDIA_BUTTONS or
                    MediaSessionCompat.FLAG_HANDLES_TRANSPORT_CONTROLS
            )
            setPlaybackState(
                PlaybackStateCompat.Builder()
                    .setActions(
                        PlaybackStateCompat.ACTION_PLAY_PAUSE or
                            PlaybackStateCompat.ACTION_SKIP_TO_NEXT or
                            PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS
                    )
                    .setState(PlaybackStateCompat.STATE_PLAYING, 0, 1f)
                    .build()
            )
            setCallback(object : MediaSessionCompat.Callback() {
                override fun onMediaButtonEvent(mediaButtonIntent: Intent): Boolean {
                    val event: KeyEvent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        mediaButtonIntent.getParcelableExtra(Intent.EXTRA_KEY_EVENT, KeyEvent::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        mediaButtonIntent.getParcelableExtra(Intent.EXTRA_KEY_EVENT)
                    }
                    return handleKeyEvent(event) ?: super.onMediaButtonEvent(mediaButtonIntent)
                }
            })
            isActive = true
        }
    }

    override fun stop() {
        clearPendingTimers()
        mediaSession?.let {
            it.isActive = false
            it.release()
        }
        mediaSession = null
        listener = null
    }

    /** Returns true/false if this KeyEvent was consumed here, or null to fall back to default OS handling. */
    private fun handleKeyEvent(event: KeyEvent?): Boolean? {
        if (event == null) return null

        return when (event.keyCode) {
            // Earbuds that already resolve next/previous themselves and
            // send it directly — pass straight through as a single real
            // gesture, no counting needed.
            KeyEvent.KEYCODE_MEDIA_NEXT -> {
                if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) sendGesture(GestureId.TAP_2)
                true
            }
            KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) sendGesture(GestureId.TAP_3)
                true
            }
            // Main button: most earbuds collapse 1/2/3 tap + hold onto
            // this single key. We do our own tap/hold resolution on top
            // of the real KeyEvent stream.
            KeyEvent.KEYCODE_HEADSETHOOK,
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
            KeyEvent.KEYCODE_MEDIA_PLAY,
            KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                when (event.action) {
                    KeyEvent.ACTION_DOWN -> {
                        if (event.repeatCount == 0) onMainButtonDown()
                        true
                    }
                    KeyEvent.ACTION_UP -> {
                        onMainButtonUp()
                        true
                    }
                    else -> true
                }
            }
            else -> null
        }
    }

    private fun onMainButtonDown() {
        holdFired = false
        holdRunnable?.let { handler.removeCallbacks(it) }
        val runnable = Runnable {
            holdFired = true
            // A hold in progress supersedes any pending tap count on this
            // same button — matches GestureEngine's "reset taps if it
            // became a hold" behavior.
            tapCount = 0
            tapRunnable?.let { handler.removeCallbacks(it) }
            sendGesture(GestureId.HOLD)
        }
        holdRunnable = runnable
        handler.postDelayed(runnable, HOLD_THRESHOLD_MS)
    }

    private fun onMainButtonUp() {
        holdRunnable?.let { handler.removeCallbacks(it) }
        if (holdFired) {
            // Hold already resolved and sent on the timer above; releasing
            // the button now is not a separate tap.
            holdFired = false
            return
        }
        registerTap()
    }

    private fun registerTap() {
        tapCount++
        tapRunnable?.let { handler.removeCallbacks(it) }
        val runnable = Runnable {
            val gestureId = when {
                tapCount >= 3 -> GestureId.TAP_3
                tapCount == 2 -> GestureId.TAP_2
                else -> GestureId.TAP_1
            }
            tapCount = 0
            sendGesture(gestureId)
        }
        tapRunnable = runnable
        handler.postDelayed(runnable, TAP_WINDOW_MS)
    }

    private fun clearPendingTimers() {
        tapRunnable?.let { handler.removeCallbacks(it) }
        holdRunnable?.let { handler.removeCallbacks(it) }
        tapCount = 0
        holdFired = false
    }

    private fun sendGesture(gestureId: String) {
        listener?.onGesture(gestureId)
    }
}
