package com.touchflow.app.earbuds

import android.content.Context

/**
 * Gesture IDs this app understands. Every source (whatever brand/SDK it
 * wraps) must resolve its own real hardware input down to one of these —
 * the rest of the app (profile mapping, real Android media/volume actions,
 * Now Playing state) only ever deals with this shared vocabulary.
 */
object GestureId {
    const val TAP_1 = "tap_1"
    const val TAP_2 = "tap_2"
    const val TAP_3 = "tap_3"
    const val HOLD = "hold"
}

/** Receives real, hardware-detected gestures from an [EarbudGestureSource]. */
fun interface EarbudGestureListener {
    fun onGesture(gestureId: String)
}

/**
 * A pluggable source of REAL earbud gestures.
 *
 * WHY THIS EXISTS: today the only implementation is
 * [AndroidMediaButtonGestureSource], which listens to Android's standard
 * media-button KeyEvents (the AVRCP mechanism most earbuds already use).
 * Adding support for a specific earbud brand's own SDK later (their own
 * Bluetooth GATT service, a manufacturer library, etc.) means writing ONE
 * new class that implements this interface and registering it in
 * [EarbudSourceRegistry] — nothing in TouchFlowMediaService, MainActivity,
 * or the WebView bridge needs to change.
 *
 * A source must NEVER invent/simulate a gesture — if the underlying
 * brand/SDK gives no real signal, the source simply reports nothing.
 * Authorization: a source may only use official, publicly documented
 * platform or vendor SDK APIs (system Bluetooth pairing, AndroidX
 * MediaSession, a manufacturer's published SDK). No direct GATT
 * read/write against arbitrary characteristics to "sniff" gestures, and
 * no interaction with a device that hasn't been paired through the
 * normal OS Bluetooth flow.
 */
interface EarbudGestureSource {
    /** Short, stable identifier for logging/diagnostics, e.g. "android_media_button". */
    val id: String

    /** Human-readable name, e.g. "Standard Android media buttons (AVRCP)". */
    val displayName: String

    /** Starts listening for real gestures. May be called multiple times; must be idempotent. */
    fun start(context: Context, listener: EarbudGestureListener)

    /** Stops listening and releases any held resources. Safe to call even if never started. */
    fun stop()
}
