package com.touchflow.app

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Build
import android.os.SystemClock
import android.view.KeyEvent
import android.webkit.JavascriptInterface

/**
 * Real Android media/volume control, exposed to JS as window.AndroidMedia.
 *
 * Everything here is only ever invoked for a gesture that genuinely
 * originated from a hardware earbud button press, resolved by
 * TouchFlowMediaService (see that file). The on-screen Demo/Test Gesture
 * area in index.html never calls this bridge — that path stays purely
 * local/simulated, exactly as before, and is never confused with real
 * hardware input.
 */
class MediaBridge(private val activity: MainActivity) {

    private val audioManager: AudioManager
        get() = activity.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    // Reads TouchFlow's native on/off master switch (see [TouchFlowPrefs]).
    // Called on app startup so the Dashboard toggle reflects reality even
    // if it was last changed via the notification button or auto-connect
    // while the app wasn't open.
    @JavascriptInterface
    fun isTouchFlowEnabled(): Boolean = TouchFlowPrefs.isEnabled(activity)

    // Mirrors the Dashboard's manual toggle into the native master switch
    // so BluetoothConnectionReceiver and the notification action see the
    // same value the user just set. Purely a preference write — never
    // starts/stops the service itself (setListening below still does
    // that, unchanged).
    @JavascriptInterface
    fun setTouchFlowEnabledPref(enabled: Boolean) {
        TouchFlowPrefs.setEnabled(activity, enabled)
    }

    // Starts/stops the real foreground media-button listening service.
    // Called from index.html only while the user is on the connected
    // Dashboard screen ("TouchFlow ON -> Ready"), and stopped the moment
    // they leave it or disconnect — the service never runs speculatively.
    @JavascriptInterface
    fun setListening(enabled: Boolean) {
        activity.runOnUiThread {
            try {
                val intent = Intent(activity, TouchFlowMediaService::class.java)
                if (enabled) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        activity.startForegroundService(intent)
                    } else {
                        activity.startService(intent)
                    }
                } else {
                    activity.stopService(intent)
                }
            } catch (e: Exception) {
                // Rare OS background-restriction edge case — fail silently
                // rather than crash the bridge call. The Demo/Test Gesture
                // area keeps working regardless of this outcome.
            }
        }
    }

    // actionId is whatever the user's ACTIVE profile has mapped a real
    // hardware gesture to (resolved in JS from the exact same mapping
    // table the on-screen Demo area uses) — this only fires for a
    // gesture that truly arrived from earbud hardware.
    @JavascriptInterface
    fun performRealAction(actionId: String) {
        activity.runOnUiThread {
            when (actionId) {
                "play_pause" -> dispatchKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
                "next" -> dispatchKey(KeyEvent.KEYCODE_MEDIA_NEXT)
                "prev" -> dispatchKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
                "vol_up" -> audioManager.adjustStreamVolume(
                    AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI
                )
                "vol_down" -> audioManager.adjustStreamVolume(
                    AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI
                )
                "mute" -> audioManager.adjustStreamVolume(
                    AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, AudioManager.FLAG_SHOW_UI
                )
                else -> {
                    // open_app / assistant / keyboard_shortcut / custom / none:
                    // no generic, honest system-wide Android equivalent
                    // exists for these — they keep going through the
                    // existing Wi-Fi PC Companion path only (ActionExecutor
                    // in index.html), unchanged.
                }
            }
        }
    }

    // Real system media-key dispatch: this reaches whatever app actually
    // owns media focus right now (Spotify, YouTube, etc.), the same way a
    // genuine wired/Bluetooth headset button does. No fake target, no
    // guessing which app is "playing".
    private fun dispatchKey(keyCode: Int) {
        val time = SystemClock.uptimeMillis()
        audioManager.dispatchMediaKeyEvent(KeyEvent(time, time, KeyEvent.ACTION_DOWN, keyCode, 0))
        audioManager.dispatchMediaKeyEvent(KeyEvent(time, time, KeyEvent.ACTION_UP, keyCode, 0))
    }
}
