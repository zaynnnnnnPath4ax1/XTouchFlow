package com.touchflow.app

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

/**
 * App-open flow required by the spec:
 *   open app -> ask Bluetooth permission -> connect earbuds ->
 *   TouchFlow ON -> Ready.
 *
 * This activity is the only Android-side entry point. It does NOT
 * re-implement any TouchFlow UI/logic — that all still lives, unmodified,
 * in assets/index.html. This class's only job is:
 *   1. Request the real Android Bluetooth runtime permissions up front.
 *   2. Host the WebView.
 *   3. Expose BluetoothBridge as window.AndroidBT so touchflow-bridge.js
 *      (the JS polyfill) can drive real native Bluetooth.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var bridge: BluetoothBridge
    private lateinit var mediaBridge: MediaBridge

    companion object {
        // Lets TouchFlowMediaService hand a real, hardware-detected
        // gesture back to the single running WebView instance. Fine for
        // this single-activity app (only one MainActivity is ever alive).
        var instance: MainActivity? = null
    }

    private val requestBtPermissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        // Whatever the result, load the app. Every individual Bluetooth
        // action from the JS side (via touchflow-bridge.js) re-checks
        // permission and will politely re-prompt if something is still
        // missing before it does a paired-device/scan/connect call. This
        // keeps normal Bluetooth pairing/media connection behavior intact
        // regardless of when permission is actually granted.
        loadTouchFlow()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            webViewClient = WebViewClient()
        }
        setContentView(webView)

        bridge = BluetoothBridge(this, webView)
        webView.addJavascriptInterface(bridge, "AndroidBT")

        mediaBridge = MediaBridge(this)
        webView.addJavascriptInterface(mediaBridge, "AndroidMedia")

        instance = this

        requestBluetoothPermissionsThenLoad()
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    /**
     * Called from TouchFlowMediaService when a REAL hardware earbud
     * button press resolves into a gesture (tap_1/tap_2/tap_3/hold).
     * This is handed to the exact same JS gesture handler
     * (app.handleGestureDetected) the on-screen Live Gesture/Demo area
     * already uses — no separate/duplicated logic, no fake detection.
     */
    fun deliverNativeGesture(gestureId: String) {
        webView.post {
            webView.evaluateJavascript(
                "window.__touchflowNativeGesture && window.__touchflowNativeGesture('$gestureId')",
                null
            )
        }
    }

    /**
     * Called from NotificationToggleReceiver when the user flips
     * TouchFlow on/off from the notification (not the Dashboard). If the
     * app happens to be open, this pushes the new state into the WebView
     * so the Dashboard toggle never shows a stale value.
     */
    fun notifyTouchFlowStateChangedFromNative(enabled: Boolean) {
        webView.post {
            webView.evaluateJavascript(
                "window.__touchflowSetEnabledFromNative && window.__touchflowSetEnabledFromNative($enabled)",
                null
            )
        }
    }

    private fun requestBluetoothPermissionsThenLoad() {
        val needed = mutableListOf<String>()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            // Android 12+
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                != PackageManager.PERMISSION_GRANTED
            ) needed.add(Manifest.permission.BLUETOOTH_CONNECT)

            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN)
                != PackageManager.PERMISSION_GRANTED
            ) needed.add(Manifest.permission.BLUETOOTH_SCAN)
        } else {
            // Android <= 11: scanning needs location permission
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED
            ) needed.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }

        // Android 13+: needed so the real media-button listening service's
        // "TouchFlow is ready" foreground notification actually shows.
        // The service itself still runs fine even if this is denied.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        if (needed.isEmpty()) {
            loadTouchFlow()
        } else {
            requestBtPermissions.launch(needed.toTypedArray())
        }
    }

    private fun loadTouchFlow() {
        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    fun ensureBluetoothEnabled(): Boolean {
        val manager = getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
        val adapter: BluetoothAdapter? = manager.adapter
        return adapter != null && adapter.isEnabled
    }

    /**
     * Called from BluetoothBridge when a JS Bluetooth call fires but
     * permission is still missing (e.g. user denied on first launch).
     * Re-prompts using the same launcher.
     */
    fun requestPermissionsIfNeeded() {
        val needed = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                != PackageManager.PERMISSION_GRANTED
            ) needed.add(Manifest.permission.BLUETOOTH_CONNECT)
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN)
                != PackageManager.PERMISSION_GRANTED
            ) needed.add(Manifest.permission.BLUETOOTH_SCAN)
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED
            ) needed.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (needed.isNotEmpty()) requestBtPermissions.launch(needed.toTypedArray())
    }

    /**
     * Hands off to Android's own system Bluetooth settings so the user
     * pairs their earbuds through the completely normal OS pairing flow
     * (preserves normal Bluetooth pairing/media connection as required).
     */
    private val pairingCallbacks = mutableListOf<(Boolean) -> Unit>()
    private val bluetoothSettingsLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { _ ->
        val cb = pairingCallbacks.removeLastOrNull()
        cb?.invoke(true)
    }

    fun launchSystemBluetoothPairing(onReturn: (Boolean) -> Unit) {
        pairingCallbacks.add(onReturn)
        bluetoothSettingsLauncher.launch(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
    }
}
