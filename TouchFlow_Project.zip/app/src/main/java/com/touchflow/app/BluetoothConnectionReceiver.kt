package com.touchflow.app

import android.Manifest
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat

/**
 * Official system broadcasts ONLY — android.bluetooth.BluetoothDevice's
 * own ACTION_ACL_CONNECTED / ACTION_ACL_DISCONNECTED, which the OS sends
 * for any Bluetooth device's link-layer connect/disconnect. No
 * background scanning, no polling, no vendor SDK involved.
 *
 * On connect: if the connecting device is already paired (bonded)
 * through the normal system Bluetooth flow, AND the user hasn't
 * explicitly turned TouchFlow off (see [TouchFlowPrefs]), start the real
 * hardware-gesture listener ([TouchFlowMediaService]) automatically —
 * the user never has to open the app or flip the Dashboard toggle by
 * hand first.
 *
 * On disconnect: stop the listener automatically.
 *
 * The manual Dashboard toggle is completely unaffected by this receiver:
 * it only ever starts the service when [TouchFlowPrefs.isEnabled] is
 * true, and that value only changes when the user themselves flips the
 * Dashboard toggle or the notification's Turn On/Off action.
 */
class BluetoothConnectionReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val device: BluetoothDevice? = getDeviceExtra(intent)

        when (intent.action) {
            BluetoothDevice.ACTION_ACL_CONNECTED -> {
                if (isBonded(context, device) && TouchFlowPrefs.isEnabled(context)) {
                    startMediaService(context)
                }
            }
            BluetoothDevice.ACTION_ACL_DISCONNECTED -> {
                stopMediaService(context)
            }
        }
    }

    private fun getDeviceExtra(intent: Intent): BluetoothDevice? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
        }
    }

    private fun isBonded(context: Context, device: BluetoothDevice?): Boolean {
        if (device == null || !hasConnectPermission(context)) return false
        return try {
            device.bondState == BluetoothDevice.BOND_BONDED
        } catch (e: SecurityException) {
            false
        }
    }

    private fun hasConnectPermission(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        return ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) ==
            PackageManager.PERMISSION_GRANTED
    }

    private fun startMediaService(context: Context) {
        val serviceIntent = Intent(context, TouchFlowMediaService::class.java)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        } catch (e: Exception) {
            // Rare OS background-start restriction edge case — fail
            // silently rather than crash a system broadcast receiver.
        }
    }

    private fun stopMediaService(context: Context) {
        try {
            context.stopService(Intent(context, TouchFlowMediaService::class.java))
        } catch (e: Exception) {
            // No-op if the service wasn't running.
        }
    }
}
