package com.touchflow.app

import android.content.Context

/**
 * Single SharedPreferences-backed source of truth for "is TouchFlow
 * enabled" — read/written by three places that all need to agree on it
 * even when the app's UI isn't open:
 *  - [BluetoothConnectionReceiver]: decides whether to auto-start the
 *    real listener when a paired earbud connects.
 *  - [NotificationToggleReceiver]: the notification's Turn On/Off action.
 *  - [MediaBridge]: keeps the Dashboard's manual toggle (in the WebView,
 *    backed by its own localStorage) in sync with the native value.
 *
 * Default is "on" so a fresh install behaves exactly like before (nothing
 * to configure before earbud gestures start working). Once the user
 * explicitly turns TouchFlow off — from the Dashboard toggle or the
 * notification button — it stays off across earbud reconnects until the
 * user turns it back on themselves. No component ever flips this value
 * except in direct response to that explicit user action.
 */
object TouchFlowPrefs {
    private const val PREFS_NAME = "touchflow_prefs"
    private const val KEY_ENABLED = "touchflow_enabled"

    fun isEnabled(context: Context): Boolean =
        context.applicationContext
            .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getBoolean(KEY_ENABLED, true)

    fun setEnabled(context: Context, enabled: Boolean) {
        context.applicationContext
            .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_ENABLED, enabled)
            .apply()
    }
}
