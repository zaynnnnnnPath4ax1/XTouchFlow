package com.touchflow.app.earbuds

/**
 * Single place that lists every real earbud gesture source TouchFlow
 * currently supports.
 *
 * TO ADD A NEW EARBUD BRAND/SDK IN THE FUTURE:
 *   1. Create a new class implementing [EarbudGestureSource] under this
 *      package (e.g. AcmeBudsGestureSource.kt), using ONLY that brand's
 *      official/public SDK or documented Bluetooth profile — never raw
 *      GATT hacking or undocumented protocol reverse-engineering.
 *   2. Add one line for it below.
 * Nothing in TouchFlowMediaService, MainActivity, MediaBridge, or the
 * WebView/JS side needs to change — they only ever depend on the shared
 * [EarbudGestureSource] contract and [GestureId] vocabulary.
 */
object EarbudSourceRegistry {
    fun createSources(): List<EarbudGestureSource> = listOf(
        AndroidMediaButtonGestureSource()
        // Future: BrandXGestureSource(), BrandYGestureSource(), ...
    )
}
