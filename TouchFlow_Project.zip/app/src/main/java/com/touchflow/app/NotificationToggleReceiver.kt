package com.touchflow.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/**
 * Handles the single action button on TouchFlow's own foreground-service
 * notification ("Turn Off" while running / "Turn On" while off) — lets
 * the user flip TouchFlow off or back on in one tap, without opening the
 * app. Only ever invoked via TouchFlow's own PendingIntent (not
 * exported), using official NotificationCompat + PendingIntent APIs.
 *
 * This is treated exactly like a manual toggle from the Dashboard: it
 * updates the same [TouchFlowPrefs] value the Dashboard toggle and the
 * auto-connect receiver both read, and pushes the new state into the
 * WebView (if the app happens to be open) so the Dashboard switch never
 * shows a stale value.
 */
class NotificationToggleReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_TURN_OFF = "com.touchflow.app.action.TURN_OFF"
        const val ACTION_TURN_ON = "com.touchflow.app.action.TURN_ON"
    }

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            ACTION_TURN_OFF -> {
                TouchFlowPrefs.setEnabled(context, false)
                // Delivered TO the running service (not a plain
                // stopService()) so it can detach its notification before
                // stopping — see TouchFlowMediaService's class doc for
                // why stopping it directly here would make the system
                // auto-remove the very notification we're about to show.
                val stopIntent = Intent(context, TouchFlowMediaService::class.java).apply {
                    action = TouchFlowMediaService.ACTION_STOP_FROM_NOTIFICATION
                }
                startServiceCompat(context, stopIntent)
                MainActivity.instance?.notifyTouchFlowStateChangedFromNative(false)
            }
            ACTION_TURN_ON -> {
                TouchFlowPrefs.setEnabled(context, true)
                startServiceCompat(context, Intent(context, TouchFlowMediaService::class.java))
                MainActivity.instance?.notifyTouchFlowStateChangedFromNative(true)
            }
        }
    }

    private fun startServiceCompat(context: Context, intent: Intent) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
    }
}
