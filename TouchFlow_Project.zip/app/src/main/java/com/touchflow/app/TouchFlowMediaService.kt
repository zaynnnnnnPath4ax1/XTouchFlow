package com.touchflow.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.touchflow.app.earbuds.EarbudGestureSource
import com.touchflow.app.earbuds.EarbudSourceRegistry

/**
 * Real hardware earbud-button listener, kept alive in the background as a
 * foreground service ("TouchFlow ON -> Ready").
 *
 * This class deliberately knows NOTHING about any specific earbud
 * brand/SDK. It just starts every [EarbudGestureSource] from
 * [EarbudSourceRegistry] and forwards whatever real gesture any of them
 * reports to the WebView via [MainActivity.deliverNativeGesture]. Adding
 * support for a new earbud brand later means adding a source to the
 * registry — this service, MainActivity, and MediaBridge never change.
 *
 * No hacking / unauthorized Bluetooth control: every source is required
 * (see [EarbudGestureSource]) to use only official platform or vendor SDK
 * APIs and only devices paired through the normal OS Bluetooth flow.
 *
 * Can be started/stopped from three places, all converging on the same
 * [TouchFlowPrefs] value: the Dashboard's manual toggle (via
 * [MediaBridge]), earbud connect/disconnect (via
 * [BluetoothConnectionReceiver]), and the notification's Turn On/Off
 * action (via [NotificationToggleReceiver]).
 *
 * IMPORTANT (see ACTION_STOP_FROM_NOTIFICATION): stopping a foreground
 * service normally makes Android auto-remove its notification. If we
 * simply called stopService() from the notification's "Turn Off" button
 * and then posted a *new* "TouchFlow is off / Turn On" notification with
 * the same ID, the system's own stop-foreground cleanup can remove that
 * replacement notification right after it appears (a real, easy-to-miss
 * race). So the "turn off from notification" path is handled *inside*
 * this service via stopForeground(STOP_FOREGROUND_DETACH), which detaches
 * the notification from the service's lifecycle *before* the service
 * actually stops — only then is it safe to update its content and leave
 * it showing.
 */
class TouchFlowMediaService : Service() {

    private var sources: List<EarbudGestureSource> = emptyList()

    companion object {
        private const val NOTIF_CHANNEL_ID = "touchflow_media"
        private const val NOTIF_ID = 1001

        /** Delivered to this service (not broadcast) when the user taps
         *  "Turn Off" on the notification — see the class doc above for
         *  why this has to be handled here rather than by the receiver
         *  directly calling stopService(). */
        const val ACTION_STOP_FROM_NOTIFICATION = "com.touchflow.app.action.STOP_FROM_NOTIFICATION"

        private fun ensureChannel(context: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    NOTIF_CHANNEL_ID,
                    "TouchFlow Ready",
                    NotificationManager.IMPORTANCE_LOW
                )
                (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                    .createNotificationChannel(channel)
            }
        }

        private fun toggleAction(context: Context, action: String, label: String): NotificationCompat.Action {
            val intent = Intent(context, NotificationToggleReceiver::class.java).apply {
                this.action = action
            }
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            return NotificationCompat.Action(0, label, pendingIntent)
        }

        private fun buildOffNotification(context: Context): android.app.Notification {
            return NotificationCompat.Builder(context, NOTIF_CHANNEL_ID)
                .setContentTitle("TouchFlow is off")
                .setContentText("Not listening for earbud gestures")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setOngoing(false)
                .addAction(toggleAction(context, NotificationToggleReceiver.ACTION_TURN_ON, "Turn On"))
                .build()
        }

        /**
         * Used when the service ISN'T currently running (e.g. it already
         * stopped for another reason, like an earbud disconnect) and we
         * still need to show the "off" state with a "Turn On" action —
         * safe to call directly since there's no foreground service
         * attached to this notification ID in that case.
         */
        fun showOffNotification(context: Context) {
            ensureChannel(context)
            (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                .notify(NOTIF_ID, buildOffNotification(context))
        }
    }

    override fun onCreate() {
        super.onCreate()
        startForegroundWithNotification()
        sources = EarbudSourceRegistry.createSources()
        sources.forEach { source ->
            source.start(this) { gestureId ->
                // Hands the REAL, hardware-detected gesture to the existing
                // WebView gesture pipeline (same handleGestureDetected()
                // the on-screen Live Gesture area already uses) — no
                // separate/duplicated logic, no fake detection.
                MainActivity.instance?.deliverNativeGesture(gestureId)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_FROM_NOTIFICATION) {
            // Detach FIRST so stopping the service doesn't auto-remove
            // this notification ID, THEN swap its content to the "off"
            // state, THEN actually stop — in that exact order.
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_DETACH)
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                .notify(NOTIF_ID, buildOffNotification(this))
            stopSelf()
            return START_NOT_STICKY
        }
        // Real background persistence: keeps listening for hardware
        // gestures even while TouchFlow's UI isn't in the foreground.
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        sources.forEach { it.stop() }
        sources = emptyList()
        super.onDestroy()
    }

    private fun startForegroundWithNotification() {
        ensureChannel(this)

        val notification = NotificationCompat.Builder(this, NOTIF_CHANNEL_ID)
            .setContentTitle("TouchFlow is ready")
            .setContentText("Listening for real earbud button gestures")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .addAction(toggleAction(this, NotificationToggleReceiver.ACTION_TURN_OFF, "Turn Off"))
            .build()

        ServiceCompat.startForeground(
            this,
            NOTIF_ID,
            notification,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
            } else 0
        )
    }
}
