package com.touchflow.app

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject

/**
 * Real native Bluetooth operations, called from JS (touchflow-bridge.js)
 * via window.AndroidBT.<method>(requestId, argsJson).
 *
 * Every method here works against the SAME BluetoothAdapter Android uses
 * for normal system pairing / A2DP media connection — nothing here
 * creates a parallel/fake Bluetooth stack, so existing pairing and media
 * behavior on the phone is completely unaffected.
 *
 * Results are sent back to JS asynchronously by evaluating
 * window.__touchflowBridgeResult(id, jsonPayload) on the WebView, since
 * @JavascriptInterface methods can't directly return values for async
 * native operations.
 */
class BluetoothBridge(private val activity: MainActivity, private val webView: WebView) {

    private val adapter: BluetoothAdapter?
        get() = (activity.getSystemService(MainActivity.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

    private fun hasConnectPermission(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        return ContextCompat.checkSelfPermission(activity, Manifest.permission.BLUETOOTH_CONNECT) ==
            PackageManager.PERMISSION_GRANTED
    }

    private fun hasScanPermission(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        return ContextCompat.checkSelfPermission(activity, Manifest.permission.BLUETOOTH_SCAN) ==
            PackageManager.PERMISSION_GRANTED
    }

    private fun resolveToJs(id: String, result: JSONObject? = null, error: String? = null) {
        val payload = JSONObject()
        if (result != null) payload.put("result", result)
        if (error != null) payload.put("error", error)
        val js = "window.__touchflowBridgeResult && window.__touchflowBridgeResult(" +
            JSONObject.quote(id) + "," + JSONObject.quote(payload.toString()) + ")"
        webView.post { webView.evaluateJavascript(js, null) }
    }

    private fun deviceToJson(device: BluetoothDevice, connected: Boolean): JSONObject {
        val o = JSONObject()
        o.put("address", device.address)
        val name = try {
            if (hasConnectPermission()) device.name ?: "" else ""
        } catch (e: SecurityException) { "" }
        o.put("name", name)
        o.put("connected", connected)
        return o
    }

    @JavascriptInterface
    fun isBluetoothAvailable(id: String, argsJson: String) {
        if (!hasConnectPermission()) {
            activity.runOnUiThread { activity.requestPermissionsIfNeeded() }
        }
        val available = adapter != null && adapter!!.isEnabled
        val result = JSONObject().put("available", available)
        resolveToJs(id, result = result)
    }

    // Devices already paired via normal Android system Bluetooth settings.
    // This mirrors Web Bluetooth's getDevices() (previously granted/known
    // devices), but backed by the real OS bonded-device list.
    @JavascriptInterface
    fun getPairedDevices(id: String, argsJson: String) {
        if (!hasConnectPermission()) {
            resolveToJs(id, error = "BLUETOOTH_CONNECT permission not granted")
            return
        }
        try {
            val bonded = adapter?.bondedDevices ?: emptySet()
            val arr = JSONArray()
            bonded.forEach { d ->
                // "connected" here reflects bonding, not an active audio
                // link (Android's public API doesn't expose per-profile
                // connection state without extra profile proxies). The
                // app's own ConnectionManager already tracks the actively
                // driven device on top of this, same as before.
                arr.put(deviceToJson(d, connected = true))
            }
            resolveToJs(id, result = JSONObject().put("devices", arr))
        } catch (e: SecurityException) {
            resolveToJs(id, error = "Bluetooth permission denied")
        }
    }

    // Hands off to Android's own Bluetooth settings screen so the user
    // does completely normal system pairing (this is intentional: Android
    // has no public "pairing dialog" API a third-party app can drive
    // directly, unlike the browser's chooser). When the user returns to
    // TouchFlow, the newest bonded device is treated as the requested one.
    @JavascriptInterface
    fun requestDevice(id: String, argsJson: String) {
        if (!hasScanPermission() || !hasConnectPermission()) {
            activity.runOnUiThread { activity.requestPermissionsIfNeeded() }
            resolveToJs(id, error = "Bluetooth permission not granted yet")
            return
        }
        activity.runOnUiThread {
            activity.launchSystemBluetoothPairing { success ->
                if (!success) {
                    resolveToJs(id, error = "Pairing cancelled")
                    return@launchSystemBluetoothPairing
                }
                try {
                    val bonded = adapter?.bondedDevices ?: emptySet()
                    val newest = bonded.lastOrNull()
                    if (newest == null) {
                        resolveToJs(id, error = "No paired device found")
                    } else {
                        resolveToJs(id, result = deviceToJson(newest, connected = true))
                    }
                } catch (e: SecurityException) {
                    resolveToJs(id, error = "Bluetooth permission denied")
                }
            }
        }
    }

    @JavascriptInterface
    fun connectDevice(id: String, argsJson: String) {
        // Actual profile-level (A2DP/HFP) connect is driven by Android
        // itself once a device is bonded/selected as active — this call
        // simply confirms bonding state so ConnectionManager's flow can
        // proceed, without touching or overriding normal media routing.
        if (!hasConnectPermission()) {
            resolveToJs(id, error = "BLUETOOTH_CONNECT permission not granted")
            return
        }
        try {
            val args = JSONObject(argsJson)
            val address = args.optString("address")
            val device = adapter?.bondedDevices?.firstOrNull { it.address == address }
            if (device == null) {
                resolveToJs(id, error = "Device not paired")
            } else {
                resolveToJs(id, result = deviceToJson(device, connected = true))
            }
        } catch (e: Exception) {
            resolveToJs(id, error = e.message ?: "connectDevice failed")
        }
    }

    @JavascriptInterface
    fun disconnectDevice(id: String, argsJson: String) {
        // No destructive action taken on the system Bluetooth connection
        // (disconnecting media here would be surprising/undesired); this
        // just updates TouchFlow's own app-level state.
        resolveToJs(id, result = JSONObject().put("ok", true))
    }

    @JavascriptInterface
    fun startScan(id: String, argsJson: String) {
        if (!hasScanPermission()) {
            activity.runOnUiThread { activity.requestPermissionsIfNeeded() }
            resolveToJs(id, error = "BLUETOOTH_SCAN permission not granted")
            return
        }
        resolveToJs(id, result = JSONObject().put("started", true))
    }

    @JavascriptInterface
    fun stopScan(id: String, argsJson: String) {
        resolveToJs(id, result = JSONObject().put("stopped", true))
    }
}
