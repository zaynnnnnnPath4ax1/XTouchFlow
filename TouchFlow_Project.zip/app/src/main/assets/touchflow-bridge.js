/*
 * TouchFlow Android Bridge
 * ------------------------
 * Purpose: Android's WebView does NOT implement navigator.bluetooth
 * (Web Bluetooth) at all. TouchFlow's existing BluetoothManager /
 * ConnectionManager classes (in index.html) are written entirely against
 * navigator.bluetooth.* — that code is NOT rewritten. Instead, this file
 * builds a navigator.bluetooth-shaped object that is backed by real native
 * Android Bluetooth calls (exposed as window.AndroidBT from MainActivity.kt).
 *
 * Flow this enables (matches the required app flow):
 *   1. App opens (MainActivity loads this WebView).
 *   2. First Bluetooth call from the page -> native runtime permission
 *      dialog (BLUETOOTH_CONNECT / BLUETOOTH_SCAN on Android 12+).
 *   3. User connects earbuds -> normal Android system Bluetooth pairing
 *      (either already-paired devices via getPairedDevices, or a fresh
 *      pair via requestDevice, which opens Android's native device picker).
 *   4. TouchFlow ON -> existing app JS proceeds exactly as before, since
 *      from its point of view navigator.bluetooth behaved normally.
 *   5. Ready.
 *
 * Normal Bluetooth pairing / A2DP media connection is untouched: this
 * bridge only ever reads paired devices / requests a connection through
 * Android's own BluetoothAdapter + system pairing UI. It never disables
 * or reroutes normal audio/media Bluetooth behavior.
 */
(function () {
    'use strict';

    // If a real navigator.bluetooth exists (e.g. testing in desktop Chrome),
    // never override it.
    if (window.navigator.bluetooth) return;

    // Bridge not injected yet (e.g. previewing this HTML in a plain browser
    // outside the Android app) -> leave navigator.bluetooth undefined so the
    // existing "Not supported in this browser" UI paths in index.html still
    // work correctly instead of throwing.
    if (typeof window.AndroidBT === 'undefined') return;

    var pending = {};
    var reqCounter = 0;
    var advertisementHandlers = [];

    function callBridge(method, args) {
        return new Promise(function (resolve, reject) {
            if (typeof window.AndroidBT[method] !== 'function') {
                reject(new Error(method + ' not available on native bridge'));
                return;
            }
            var id = 'req_' + (++reqCounter);
            pending[id] = { resolve: resolve, reject: reject };
            try {
                window.AndroidBT[method](id, JSON.stringify(args || {}));
            } catch (e) {
                delete pending[id];
                reject(e);
            }
        });
    }

    // Called FROM native (Android side) via evaluateJavascript once an
    // async native Bluetooth operation finishes.
    window.__touchflowBridgeResult = function (id, payloadJson) {
        var entry = pending[id];
        if (!entry) return;
        delete pending[id];
        var payload;
        try { payload = JSON.parse(payloadJson); } catch (e) { payload = {}; }
        if (payload.error) entry.reject(new Error(payload.error));
        else entry.resolve(payload.result);
    };

    // Called FROM native whenever a BLE advertisement is seen during an
    // active requestLEScan() session.
    window.__touchflowBridgeAdvertisement = function (deviceJson) {
        var raw;
        try { raw = JSON.parse(deviceJson); } catch (e) { return; }
        var device = makeDevice(raw);
        advertisementHandlers.forEach(function (h) {
            try { h({ device: device, rssi: raw.rssi }); } catch (e) { console.warn(e); }
        });
    };

    function makeDevice(raw) {
        var device = {
            id: raw.address,
            name: raw.name || '',
            addEventListener: function () {},
            removeEventListener: function () {}
        };
        device.gatt = {
            connected: !!raw.connected,
            connect: function () {
                return callBridge('connectDevice', { address: raw.address }).then(function () {
                    device.gatt.connected = true;
                    return device.gatt;
                });
            },
            disconnect: function () {
                return callBridge('disconnectDevice', { address: raw.address }).then(function () {
                    device.gatt.connected = false;
                });
            }
        };
        return device;
    }

    window.navigator.bluetooth = {
        // Triggers the native permission prompt (if not already granted)
        // the first time it's called.
        getAvailability: function () {
            return callBridge('isBluetoothAvailable').then(function (r) {
                return !!(r && r.available);
            });
        },

        // Real "already granted/paired" devices, same contract as
        // navigator.bluetooth.getDevices() in Chrome.
        getDevices: function () {
            return callBridge('getPairedDevices').then(function (r) {
                return (r && r.devices ? r.devices : []).map(makeDevice);
            });
        },

        // Opens Android's native device chooser / triggers normal system
        // Bluetooth pairing for a new earbud.
        requestDevice: function (options) {
            return callBridge('requestDevice', options || {}).then(makeDevice);
        },

        requestLEScan: function (options) {
            return callBridge('startScan', options || {}).then(function () {
                return {
                    active: true,
                    stop: function () { return callBridge('stopScan'); }
                };
            });
        },

        addEventListener: function (type, handler) {
            if (type === 'advertisementreceived') advertisementHandlers.push(handler);
        },
        removeEventListener: function (type, handler) {
            if (type === 'advertisementreceived') {
                advertisementHandlers = advertisementHandlers.filter(function (h) { return h !== handler; });
            }
        }
    };
})();
